<?php
include "db_con.php";

?>
<!DOCTYPE html>
<html>
<head>
<title>
INDEX</title>
</head>
<body>
	<?php
if(isset($_GET['id']))
{
	?> Hello <?php echo $_GET['id']; 
}
?>
<h1 style="color:green">HELLO WORLD!</h1>
<a href="logout.php">LOGOUT</a>
</body>
</html>