<?php
include 'db_con.php';
session_destroy();
header('location:login.php');


?>