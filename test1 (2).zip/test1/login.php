<?php
include "db_con.php";
if(isset($_POST['submit'])){
	$email=$_POST['email'];
	$password=$_POST['password'];
	$sql="select * from tbl_form where pass='$password'";
	$cbs=mysqli_query($con,$sql);
	$fetch=mysqli_fetch_array($cbs,MYSQLI_ASSOC);
	$count=mysqli_num_rows($cbs);

	if($count==1){
		
		header('location:index.php?id=<?php echo $email; ?>');
	}
	else
	{
		echo "<h1><center>Login failed</center></h1>";

	mysqli_error($con);
}
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	
</head>
<body>
	<h1>LOGIN FORM</h1>
	<form name="abc" action="login.php" method="post" enctype="multipart/form-data" onsubmit="return validation()">
		
		<input type="email" name="email" placeholder="EMAIL"><br><br>
		<input type="password" name="password" placeholder="PASSWORD"><br><br>
		<input type="submit" name="submit" value="SUBMIT" onclick="return valid()"><br><br>
	</form>
</body>
</html>