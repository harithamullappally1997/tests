<?php 
include "db_con.php";

if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$age=$_POST['age'];
	$email=$_POST['email'];
	$password=$_POST['password'];

	$sql="INSERT INTO `tbl_form` (`name`,`age`,`email`,`pass`) VALUES ('$name','$age','$email','$password')";
	if(mysqli_query($con,$sql))
	{
        echo "<h1>Registration successful</h1>";
	} else { 
	mysqli_error($con);
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title >Registration form</title>
</head>
<body>
	<div>
<h1> REGISTRATION FORM</h1>
<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
<div class="form-group">
    <label for="exampleInputEmail1">Name</label><br>
<input type="text" name="name" placeholder="NAME" required="">
</div>
<div class="form-group">
    <label for="exampleInputEmail1">Age</label><br>
<input type="text" name="age" placeholder="AGE" required="">
</div>
<div class="form-group">
    <label for="exampleInputEmail1">Email address</label><br>
<input type="email" name="email" placeholder="EMAIL" required>
</div>
<div class="form-group">
    <label for="exampleInputEmail1">Password</label><br>
<input type="password" name="password" placeholder="Password">
</div>
<div class="form-group">
    <label for="exampleInputEmail1">Confirm Password</label><br>
<input type="password" name="cpass" placeholder="Confirm Password">
</div>

<input type="submit" class="btn btn-primary" name="submit" placeholder="SUBMIT" onclick="return valid()">
</div>
</form>
</div>
<a href="login.php">LOGIN</a>
</body>
</html>
